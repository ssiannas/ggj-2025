﻿namespace ggj_2025
{
    public enum PlayerState
    {
        IDLE,
        WALK_LEFT,
        WALK_RIGHT,
        WALK_UP,
        WALK_DOWN,
    }
}